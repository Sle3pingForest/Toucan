package toucan.modele;

public class Algo {
	
	public Algo () {
		
	}
	
	public void trier() {
		
	}

}
